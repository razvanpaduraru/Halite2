Etapa 1, Proiect PA, Halite 2
Echipa: NPcompete, Seria CA
Membri: Micu Ana-Maria, 321CA
        Paduraru Razvan-Stefan, 321CA
        Cornea Doru-Andrei, 321CA
        Gavan Adrian-George, 324CA

1. Instructiuni de compilare:
    Se va rula ./run_game.sh care va genera un fisier Makefile dupa care se
va rula make in folderul in care exista MyBot.cpp, iar apoi, in folderul
halite-II-resources-master se muta executabilul MyBot, iar inainte de a se da
comanda python ./run.py --cmd "./MyBot" --round 1, se va da permisiune de
executare pentru fisierul /environment/set_version.sh
(chmod 777 ./environment/set_version.sh).

2. Detalii despre structura si abordare:
    Am pornit de la starter-kit-ul existent pe site si nu am modificat decat
MyBot.cpp. 

    Principala idee a fost sa trimitem cel putin o nava catre fiecare planeta.
Prin urmare, am construit vectorul to_go_planets care contine id-urile
planetelor catre care se va indrepta cel putin o nava. O alta idee a fost sa
pastram planeta destinatie a fiecarei nave de la o mutare la alta. Asadar, am
construit map-ul to_dock care contine perechi de forma {ship_id, Planet} si pe
care il vom actualiza constant de la o mutare la alta.

    Pentru a stabili mutarea fiecarei nave, am parcurs vectorul de nave si:
        - daca nava este "Docked", o omitem;
        - cautam nava in map-ul to_dock, pentru a vedea daca i-am stabilit deja
o planeta destinatie;
        - in caz afirmativ, facem o mutare prin care o trimitem mai aproape de
destinatie;
        - in caz negativ, cautam o noua planeta catre care nu se indrepta nicio
alta nava (ne folosim de vectorul to_go_planets);

    Pentru a evita coliziunile, am testat daca distanta de la nava curenta la
orice alta nava este mai mica decat distanta maxima pe care o poate parcurge la
o mutare. In caz afirmativ, i-am adaugat mutarea in vectorul de mutari. In caz
negativ (exista cel putin o coliziune cu o alta nava), i-am pastrat pozitia
curenta pana la urmatoarea mutare.

3. Surse de inspiratie:
    La aceasta etapa, avand in vedere ca nu am folosit vreun algoritm avansat,
am folosit ca unica sursa de inspiratie sfaturile pentru incepatori de pe
site-ul jocului si pagina cu detalii despre functiile deja implementate in
starter-kit.

4. Responsabilitatea fiecarui membru:
    Scrierea codului: Micu Ana-Maria, Paduraru Razvan-Stefan
    Debug: Cornea Doru-Andrei, Paduraru Razvan-Stefan
    Strategie si cercetare: Micu Ana-Maria, Gavan Adrian-George
    Tester: Gavan Adrian-George, Cornea Doru-Andrei
