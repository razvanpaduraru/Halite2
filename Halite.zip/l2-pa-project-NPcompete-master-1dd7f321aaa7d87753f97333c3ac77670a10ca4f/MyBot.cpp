#include "hlt/hlt.hpp"
#include "hlt/navigation.hpp"
#include <unordered_map>
#include <math.h>
#include <algorithm>

struct Comp {
  Comp(hlt::Location ship_location) {
    this->ship_location = ship_location;
  }
  
  bool operator () (hlt::Entity &entity1, hlt::Entity &entity2) {
    double diff1, diff2;

    diff1 = ship_location.get_distance_to(entity1.location);
    diff2 = ship_location.get_distance_to(entity2.location);

    return (diff1 < diff2);
  }
  
  hlt::Location ship_location;
};


int main() {
  const hlt::Metadata metadata = hlt::initialize("NPcompete");
  const hlt::PlayerId player_id = metadata.player_id;

  const hlt::Map& initial_map = metadata.initial_map;

  std::ostringstream initial_map_intelligence;
  initial_map_intelligence
            << "width: " << initial_map.map_width
            << "; height: " << initial_map.map_height
            << "; players: " << initial_map.ship_map.size()
            << "; my ships: " << initial_map.ship_map.at(player_id).size()
            << "; planets: " << initial_map.planets.size();
  hlt::Log::log(initial_map_intelligence.str());

  std::vector<hlt::Move> moves;
  std::vector<hlt::Ship> enemy_ships;
  std::vector<hlt::Planet> planets;
  
  hlt::PlayerId enemy_id = 0;

  for (;;) {
    moves.clear();
    enemy_ships.clear();
    hlt::Map map = hlt::in::get_map();
    planets = map.planets;

    /* Aflarea PlayerId-ul adversarului */
    bool found_enemy_id = false;
    for (auto pair : map.ships) {
      if (found_enemy_id) {
        break;
      }
      
      for (auto ship : pair.second) {
        if (!found_enemy_id) {
          found_enemy_id = true;
          enemy_id = ship.owner_id;
          break;
        }
      }
    }
    
    for (const hlt::Ship& ship : map.ships.at(player_id)) {

      /* Verificare daca nava este Docked */
      if (ship.docking_status != hlt::ShipDockingStatus::Undocked) {
        continue;
      }
      
      /* Selectarea tuturor navelor adversarului */
      for (auto pair : map.ships) {
        if (pair.first == enemy_id) {
          for (auto ship : pair.second) {
            enemy_ships.push_back(ship);
          }
        }
      }
      
      /* Sortarea navelor adversarului (prioritate au cele mai apropiate) */
      sort(enemy_ships.begin(), enemy_ships.end(), Comp(ship.location));

      if (enemy_ships.size() - map.ships.at(player_id).size() <
                                               hlt::constants::MAX_DIFF) {
        hlt::Ship enemy_ship = enemy_ships.front();
        const hlt::possibly<hlt::Move> move =
              hlt::navigation::navigate_ship_towards_target(
                map,
                ship,
                ship.location.get_closest_point(enemy_ship.location,
                                               2 * hlt::constants::SHIP_RADIUS),
                hlt::constants::MAX_SPEED,
                true,
                hlt::constants::MAX_NAVIGATION_CORRECTIONS,
                M_PI / 180);

        if (move.second) {
          moves.push_back(move.first);
        }

        continue;
      }
      
      /* Sortarea planetelor (prioritate au cele mai apropiate) */
      sort(planets.begin(), planets.end(), Comp(ship.location));
      
      /* Alegerea unei planete destinatie */
      for (auto planet : planets) {
        if (!planet.owned) {
          continue;
        }
        
        if (planet.is_full()) {
          continue;
        }
        
        if (ship.can_dock(planet)) {
          const hlt::Move move = hlt::Move::dock(ship.entity_id,
                                                 planet.entity_id);
          moves.push_back(move);

          break;
        }
        
        const hlt::possibly<hlt::Move> move =
              hlt::navigation::navigate_ship_to_dock(
                map,
                ship,
                planet,
                hlt::constants::MAX_SPEED);

        if (move.second) {
          moves.push_back(move.first);
          break;
        }
      }
    }

    /* Execut mutarile */
    if (!hlt::out::send_moves(moves)) {
      hlt::Log::log("send_moves failed; exiting");
      break;
    }
  }
}
